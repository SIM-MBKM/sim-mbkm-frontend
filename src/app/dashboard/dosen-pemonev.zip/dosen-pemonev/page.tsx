import { DashboardLayoutDosen } from "@/components/dashboard/dashboard-layout-dosen";
import { DosenPemonevLayout, DosenPemonevMainDashboard } from "@/components/dashboard/dosen-pemonev/layout";
import { ProtectedDashboardLayout } from "@/components/dashboard/protected-dashboard-layout";

export default function DosenPemonevDashboardPage() {
  return (
    <ProtectedDashboardLayout allowedRole="DOSEN PEMONEV">
      <DashboardLayoutDosen>
        <DosenPemonevLayout>
          <DosenPemonevMainDashboard />
        </DosenPemonevLayout>
      </DashboardLayoutDosen>
    </ProtectedDashboardLayout>
  );
}
