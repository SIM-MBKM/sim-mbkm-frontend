import { DosenPemonevLayout, DosenPemonevMonevPage } from "@/components/dashboard/dosen-pemonev/layout";

export default function DosenPemonevMonevManagementPage() {
  return (
    <DosenPemonevLayout>
      <DosenPemonevMonevPage />
    </DosenPemonevLayout>
  );
}
